import 'package:flutter/material.dart';

class Footer extends StatefulWidget {
  const Footer({Key? key}) : super(key: key);

  @override
  State<Footer> createState() => _FooterState();
}

class _FooterState extends State<Footer> {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: <Widget>[
        IconButton(
          onPressed: () {
            debugPrint("d");
          },
          iconSize: 40,
          icon: const Icon(Icons.map_outlined),
        ),
        IconButton(
          onPressed: () {
            debugPrint("d");
          },
          iconSize: 70,
          icon: const Icon(Icons.pause_circle_outline),
        ),
        IconButton(
          onPressed: () {
            debugPrint("d");
          },
          iconSize: 40,
          icon: const Icon(Icons.run_circle_outlined),
        ),
        // Text('d1'),
        // RawMaterialButton(
        //   onPressed: () {},
        //   elevation: 2.0,
        //   fillColor: Colors.black,
        //   child: Icon(
        //     Icons.pause,
        //     size: 35.0,
        //   ),
        //   padding: EdgeInsets.all(15.0),
        //   shape: CircleBorder(),
        // ),
      ],
    );
  }
}
