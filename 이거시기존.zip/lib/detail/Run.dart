import 'package:flutter/material.dart';

class Run extends StatelessWidget {
  const Run({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: 1,
      child: Column(
        children: [
          const Text(
            '0.73',
            style: TextStyle(
              fontSize: 60,
            ),
          ),
          const Text(
            'kilometers',
            style: TextStyle(
              color: Colors.grey,
              fontSize: 18,
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const <Widget>[
              Icon(
                Icons.run_circle,
                size: 50,
              ),
              SizedBox(
                height: 60,
              ),
              Text(
                ' +8.25',
                style: TextStyle(
                    color: Colors.amber,
                    fontSize: 32,
                    fontWeight: FontWeight.bold),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
