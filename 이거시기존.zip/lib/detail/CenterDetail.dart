import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_gauges/gauges.dart';

class CenterDetail extends StatelessWidget {
  final String dataData;
  const CenterDetail({required this.dataData, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: <Widget>[
        SizedBox(
          width: 70,
          height: 180,
          child: Column(
            children: const <Widget>[
              Text(
                '20:15',
                style: TextStyle(
                  fontSize: 25,
                  color: Colors.black,
                ),
              ),
              SizedBox(
                height: 10,
              ),
              Icon(
                Icons.timer_outlined,
                color: Colors.black,
                size: 24,
              ),
            ],
          ),
        ),
        Column(
          children: <Widget>[
            const Text(
              '7.5km/h',
              style: TextStyle(
                fontSize: 25,
                color: Colors.black,
              ),
            ),
            SizedBox(
              width: 130,
              height: 150,
              child: SfRadialGauge(axes: <RadialAxis>[
                RadialAxis(minimum: 0, maximum: 150, ranges: <GaugeRange>[
                  GaugeRange(
                      startValue: 0,
                      endValue: 50,
                      color: Colors.green,
                      startWidth: 10,
                      endWidth: 10),
                  GaugeRange(
                      startValue: 50,
                      endValue: 100,
                      color: Colors.orange,
                      startWidth: 10,
                      endWidth: 10),
                  GaugeRange(
                      startValue: 100,
                      endValue: 150,
                      color: Colors.red,
                      startWidth: 10,
                      endWidth: 10)
                ], pointers: const <GaugePointer>[
                  NeedlePointer(value: 50)
                ], annotations: <GaugeAnnotation>[
                  GaugeAnnotation(
                      widget: Container(
                          child: const Text('90.0',
                              style: TextStyle(
                                  fontSize: 25, fontWeight: FontWeight.bold))),
                      angle: 90,
                      positionFactor: 0.5)
                ])
              ]),
            ),
          ],
        ),
        SizedBox(
          width: 70,
          height: 180,
          child: Column(
            children: <Widget>[
              Text(
                dataData,
                style: const TextStyle(
                  fontSize: 25,
                  color: Colors.black,
                ),
              ),
              const SizedBox(
                height: 10,
              ),
              const Icon(
                Icons.crisis_alert_outlined,
                color: Colors.black,
                size: 24,
              ),
            ],
          ),
        ),
      ],
    );
  }
}
