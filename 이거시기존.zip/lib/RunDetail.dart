import 'package:flutter/material.dart';
import 'dart:async';

import 'package:permission_handler/permission_handler.dart';
import 'package:pedometer/pedometer.dart';
import 'package:geolocator/geolocator.dart';

import 'detail/Top.dart';
import 'detail/Run.dart';
import 'detail/CenterDetail.dart';
import 'detail/Footer.dart';

String formatDate(DateTime d) {
  return d.toString().substring(0, 19);
}

class RunDetail extends StatefulWidget {
  const RunDetail({Key? key}) : super(key: key);

  @override
  State<RunDetail> createState() => _RunDetailState();
}

class _RunDetailState extends State<RunDetail> {
  double speedInMps = 0;
  Position? _position;

  late Stream<StepCount> _stepCountStream;
  late Stream<PedestrianStatus> _pedestrianStatusStream;
  String _status = '?', _steps = '?';

  void _getCurrentLocation() async {
    Position position = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );

    Geolocator.getPositionStream().listen((position) {
      setState(() {
        speedInMps = position.speed;
      });
    });

    setState(() {
      _position = position;
    });
  }

  Future<Position> _determinePosition() async {
    LocationPermission permission;
    // LocationPermission permission = await Geolocator.checkPermission();
    permission = await Geolocator.checkPermission();

    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();

      if (permission == LocationPermission.denied) {
        return Future.error('error');
      }
    }

    return await Geolocator.getCurrentPosition();
  }

  @override
  void initState() {
    super.initState();
    initPlatformState();
    print("dddd");
  }

  void onStepCount(StepCount event) {
    // 11111111111111111111111111
    print("1111111111111 $event");
    setState(() {
      _steps = event.steps.toString();
      // _steps = "0";
    });
  }

  void onPedestrianStatusChanged(PedestrianStatus event) {
    //  22222222222222222222222222
    print("2222222222 $event");
    setState(() {
      _status = event.status;
    });
  }

  void onPedestrianStatusError(error) {
    print("333333333 $error");

    print('onPedestrianStatusError: $error');
    setState(() {
      _status = 'Pedestrian Status not available';
    });
  }

  void onStepCountError(error) {
    print("444444444 $error");

    print('onStepCountError: $error');
    setState(() {
      _steps = 'Step Count not available';
    });
  }

  void initPlatformState() async {
    if (await Permission.activityRecognition.request().isGranted) {
      _pedestrianStatusStream = Pedometer.pedestrianStatusStream;
      _pedestrianStatusStream
          .listen(onPedestrianStatusChanged)
          .onError(onPedestrianStatusError);

      _stepCountStream = Pedometer.stepCountStream;
      _stepCountStream.listen(onStepCount).onError(onStepCountError);
    }

    if (!mounted) return;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.blue,
        elevation: 0.0,
        titleSpacing: 10,
        leading: null,
        title: Wrap(
          crossAxisAlignment: WrapCrossAlignment.center,
          children: const <Widget>[
            ClipRect(
              child: Icon(
                Icons.run_circle,
                color: Colors.white,
              ),
            ),
            SizedBox(
              width: 4,
            ),
            Text(
              'Running',
              style: TextStyle(color: Colors.white),
            ),
          ],
        ),
      ),
      body: Column(
        children: <Widget>[
          Top(),
          SizedBox(height: 50),
          CenterDetail(
            dataData: _steps,
          ),
          SizedBox(height: 10),
          Run(),
          Footer(),
        ],
      ),
    );
  }
}


// body: Container(
//         child: _position != null
//             ? Column(
//                 children: <Widget>[
//                   Text('Current Location:' + _position.toString()),
//                   Text('Current speed:' + speedInMps.toString()),
//                 ],
//               )
//             : Text('null'),
//       ),
//       floatingActionButton: FloatingActionButton(
//         onPressed: _getCurrentLocation,
//         tooltip: 'Increment',
//         child: const Icon(Icons.add),
//       ),