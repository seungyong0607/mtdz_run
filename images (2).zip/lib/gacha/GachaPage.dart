import 'package:flutter/material.dart';

class GachaPage extends StatelessWidget {
  const GachaPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("뽑기 페이지")),
    );
  }
}
